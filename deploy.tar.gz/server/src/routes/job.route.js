const express = require("express");
const isAuthenticated = require("../middlewares/auth.js");
const {
  getAdminJobs,
  getAllJobs,
  getJobById,
  postJob,
  deleteAdminJobs,
  getSimilarJobs,
  updateJob,
  getJobFilters,
  getJobsForCarousel,

} = require("../controllers/job.controller.js");

const jobRouter = express.Router();

jobRouter.route("/post").post(isAuthenticated, postJob);
jobRouter.route("/get").get(getAllJobs);
jobRouter.route("/getadminjobs").get(isAuthenticated, getAdminJobs);
jobRouter.route("/get/:id").get(getJobById);
jobRouter.route("/update/:id").put(isAuthenticated, updateJob);
jobRouter.route("/delete/:id").delete(isAuthenticated, deleteAdminJobs);
jobRouter.route("/:id/similar").get(getSimilarJobs);
jobRouter.route("/filters").get(getJobFilters);
jobRouter.route("/carousel").get(getJobsForCarousel);

module.exports = jobRouter;
